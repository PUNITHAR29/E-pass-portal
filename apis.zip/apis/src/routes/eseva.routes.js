const express = require('express')
const router = express.Router()
const esevaController = require('../controllers/eseva.controller');
// Retrieve all employees
router.get('/', esevaController.findAll);
// Create a new employee
router.post('/', esevaController.create);
// Retrieve a single employee with id
router.get('/:id', esevaController.findById);
// Update a employee with id
router.put('/:id', esevaController.update);
// Delete a employee with id
router.delete('/:id', esevaController.delete);
module.exports = router