'use strict';
var dbConn = require('./../../config/db.config');
//Employee object create
var esevaUser = function (user) {
        this.phnum = user.phnum,
        this.firstname = user.firstname,
        this.lastname = user.lastname,
        this.address = user.address,
        this.age = user.age,
        this.from = user.from,
        this.to = user.to,
        this.reason = user.reason,
        this.noofperson = user.noofperson,
        this.modeoftransport = user.modeoftransport,
        this.datecr = new Date();   
        this.approval_status = user.approval_status; 
        this.filename = user.filename;
};
esevaUser.create = function (newUser, result) {
    dbConn.query("INSERT INTO userdetails set ?", newUser, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });
};
esevaUser.findById = function (id, result) {
    dbConn.query("Select * from userdetails where phnum = ? ", id, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            result(null, res);
        }
    });
};

esevaUser.findAll = function (result) {
    dbConn.query("Select * from userdetails where approval_status= 'Pending' ", function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            console.log('employees : ', res);
            result(null, res);
        }
    });
};
esevaUser.update = function (id, user, result) {
    console.log('user.approval_status=->',user);
    dbConn.query("UPDATE userdetails SET approval_status=? WHERE id = ?",[user.approval_status,id], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        } else {
            result(null, res);
        }
    });
};
esevaUser.delete = function (id, result) {
    dbConn.query("DELETE FROM userdetails WHERE id = ?", [id], function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            result(null, res);
        }
    });
};

module.exports = esevaUser;