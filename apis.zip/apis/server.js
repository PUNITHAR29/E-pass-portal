const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
var multer = require('multer')
// create express app
const app = express();
// Setup server port
const port = process.env.PORT || 5000;
// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }))
// parse requests of content-type - application/json
app.use(bodyParser.json())

app.use(cors());

// define a root route
app.get('/', (req, res) => {
  res.send("Hello World");
});

// file upload
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'public')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
});

var upload = multer({ storage: storage }).single('file');

app.post('/upload', function (req, res) {

  upload(req, res, function (err) {
    if (err instanceof multer.MulterError) {
      return res.status(500).json(err)
    } else if (err) {
      return res.status(500).json(err)
    }
    return res.status(200).send(req.file)

  })

});

app.get('/getimage/:filename', (req, res) => {  
  console.log('filename=-=->',req.params.filename)
  let imgUrl = './public/'+req.params.filename;
  console.log('imgUrl--->',imgUrl);
  res.writeHead(200, { 'content-type': 'image/jpg' });
  fs.createReadStream(imgUrl).pipe(res);  
});

// Require employee routes
const esevaRoutes = require('./src/routes/eseva.routes')
// using as middleware
app.use('/api/eseva/user', esevaRoutes)
// listen for requests
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});