'use strict';
const mysql = require('mysql');
//local mysql db connection
const dbConn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'eseva'
});
dbConn.connect(function (err) {
  if (!err) {        
    console.log("Database Connected!");
  } else {
    console.log(err);
  }
});
module.exports = dbConn;


// Devadmin /Dev#admin$123